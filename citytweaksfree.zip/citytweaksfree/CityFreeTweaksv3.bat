@echo off
setlocal EnableExtensions EnableDelayedExpansion
title Sin City Free Tweaks
mode con cols=92 lines=34
color 0D

:: =========================================================
:: SIN CITY FREE TWEAKS
:: saintsnsinners.org
:: =========================================================

:: ---------- ADMIN CHECK ----------
net session >nul 2>&1
if errorlevel 1 (
    cls
    echo.
    echo.
    echo                              SIN CITY FREE TWEAKS
    echo.
    echo                         Requesting administrator access...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    if errorlevel 1 (
        echo.
        echo                         ERROR SC-ADM-001
        echo                         Administrator access was denied.
        echo.
        pause
    )
    exit /b
)

set "ACCENT=D"
set "STATUS=Ready"
set "LASTERROR=NONE"

call :intro
goto menu


:: =========================================================
:: MAIN MENU
:: =========================================================
:menu
cls
color 0%ACCENT%
echo.
echo                         ==========================================
echo                                  S I N   C I T Y
echo                               F R E E   T W E A K S
echo                         ==========================================
echo.
echo                                  Windows Performance
echo.
echo                         [1]  High Performance Power Plan
echo                         [2]  Enable Windows Game Mode
echo                         [3]  Disable Xbox Game DVR
echo                         [4]  Disable Mouse Acceleration
echo                         [5]  Reduce Windows Visual Effects
echo                         [6]  Disable Transparency Effects
echo                         [7]  Remove Windows Startup Delay
echo                         [8]  Flush DNS Cache
echo                         [9]  Clean User Temporary Files
echo                         [10] Disable Hibernation
echo.
echo                         [A]  Apply All Free Tweaks
echo                         [S]  System Info
echo                         [C]  Change Accent Color
echo                         [R]  Recommendations
echo                         [Q]  Exit
echo.
echo                         ------------------------------------------
echo                         Status : !STATUS!
echo                         Support: !LASTERROR!
echo                         ------------------------------------------
echo                         More tweaks: saintsnsinners.org
echo.
set "choice="
set /p "choice=                         Select an option: "

if /I "!choice!"=="1" goto tweak1
if /I "!choice!"=="2" goto tweak2
if /I "!choice!"=="3" goto tweak3
if /I "!choice!"=="4" goto tweak4
if /I "!choice!"=="5" goto tweak5
if /I "!choice!"=="6" goto tweak6
if /I "!choice!"=="7" goto tweak7
if /I "!choice!"=="8" goto tweak8
if /I "!choice!"=="9" goto tweak9
if /I "!choice!"=="10" goto tweak10
if /I "!choice!"=="A" goto applyall
if /I "!choice!"=="S" goto sysinfo
if /I "!choice!"=="C" goto colors
if /I "!choice!"=="R" goto recommend
if /I "!choice!"=="Q" goto end

set "STATUS=Invalid option."
goto menu


:: =========================================================
:: TWEAKS
:: =========================================================
:tweak1
call :progress "POWER"
powercfg /setactive SCHEME_MIN >nul 2>&1
if errorlevel 1 goto err_pwr1
set "STATUS=High Performance power plan enabled."
set "LASTERROR=NONE"
goto done

:tweak2
call :progress "GAME MODE"
reg add "HKCU\Software\Microsoft\GameBar" /v "AutoGameModeEnabled" /t REG_DWORD /d 1 /f >nul 2>&1
if errorlevel 1 goto err_gme1
reg add "HKCU\Software\Microsoft\GameBar" /v "AllowAutoGameMode" /t REG_DWORD /d 1 /f >nul 2>&1
if errorlevel 1 goto err_gme1
set "STATUS=Windows Game Mode enabled."
set "LASTERROR=NONE"
goto done

:tweak3
call :progress "GAME DVR"
reg add "HKCU\System\GameConfigStore" /v "GameDVR_Enabled" /t REG_DWORD /d 0 /f >nul 2>&1
if errorlevel 1 goto err_dvr1
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR" /v "AppCaptureEnabled" /t REG_DWORD /d 0 /f >nul 2>&1
if errorlevel 1 goto err_dvr1
set "STATUS=Xbox Game DVR disabled."
set "LASTERROR=NONE"
goto done

:tweak4
call :progress "MOUSE"
reg add "HKCU\Control Panel\Mouse" /v "MouseSpeed" /t REG_SZ /d "0" /f >nul 2>&1
if errorlevel 1 goto err_mse1
reg add "HKCU\Control Panel\Mouse" /v "MouseThreshold1" /t REG_SZ /d "0" /f >nul 2>&1
if errorlevel 1 goto err_mse1
reg add "HKCU\Control Panel\Mouse" /v "MouseThreshold2" /t REG_SZ /d "0" /f >nul 2>&1
if errorlevel 1 goto err_mse1
set "STATUS=Mouse acceleration disabled."
set "LASTERROR=NONE"
goto done

:tweak5
call :progress "VISUALS"
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects" /v "VisualFXSetting" /t REG_DWORD /d 2 /f >nul 2>&1
if errorlevel 1 goto err_vfx1
set "STATUS=Visual effects set for performance."
set "LASTERROR=NONE"
goto done

:tweak6
call :progress "TRANSPARENCY"
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize" /v "EnableTransparency" /t REG_DWORD /d 0 /f >nul 2>&1
if errorlevel 1 goto err_ui1
set "STATUS=Transparency effects disabled."
set "LASTERROR=NONE"
goto done

:tweak7
call :progress "STARTUP"
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Serialize" /v "StartupDelayInMSec" /t REG_DWORD /d 0 /f >nul 2>&1
if errorlevel 1 goto err_boot1
set "STATUS=Windows startup delay removed."
set "LASTERROR=NONE"
goto done

:tweak8
call :progress "NETWORK"
ipconfig /flushdns >nul 2>&1
if errorlevel 1 goto err_net1
set "STATUS=DNS cache flushed."
set "LASTERROR=NONE"
goto done

:tweak9
call :progress "CLEANUP"
if not defined TEMP goto err_cln1
if not exist "%TEMP%" goto err_cln1

set /a COUNT=0
for /f "delims=" %%F in ('dir /a-d /b /s "%TEMP%\*" 2^>nul') do (
    del /f /q "%%F" >nul 2>&1
    if not exist "%%F" set /a COUNT+=1 >nul
)
for /f "delims=" %%D in ('dir /ad /b /s "%TEMP%\*" 2^>nul ^| sort /R') do (
    rd /s /q "%%D" >nul 2>&1
)
set "STATUS=Temporary files cleaned. Removed !COUNT! files."
set "LASTERROR=NONE"
goto done

:tweak10
call :progress "HIBERNATION"
powercfg /hibernate off >nul 2>&1
if errorlevel 1 goto err_pwr2
set "STATUS=Hibernation disabled."
set "LASTERROR=NONE"
goto done


:: =========================================================
:: APPLY ALL
:: =========================================================
:applyall
cls
color 0%ACCENT%
echo.
echo.
echo                         ==========================================
echo                                  APPLY ALL
echo                         ==========================================
echo.
echo                         Applying the free Sin City preset...
echo.

call :progress "POWER"
powercfg /setactive SCHEME_MIN >nul 2>&1
if errorlevel 1 goto err_all1

call :progress "GAMING"
reg add "HKCU\Software\Microsoft\GameBar" /v "AutoGameModeEnabled" /t REG_DWORD /d 1 /f >nul 2>&1
if errorlevel 1 goto err_all2
reg add "HKCU\Software\Microsoft\GameBar" /v "AllowAutoGameMode" /t REG_DWORD /d 1 /f >nul 2>&1
if errorlevel 1 goto err_all2
reg add "HKCU\System\GameConfigStore" /v "GameDVR_Enabled" /t REG_DWORD /d 0 /f >nul 2>&1
if errorlevel 1 goto err_all2
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR" /v "AppCaptureEnabled" /t REG_DWORD /d 0 /f >nul 2>&1
if errorlevel 1 goto err_all2

call :progress "WINDOWS"
reg add "HKCU\Control Panel\Mouse" /v "MouseSpeed" /t REG_SZ /d "0" /f >nul 2>&1
if errorlevel 1 goto err_all3
reg add "HKCU\Control Panel\Mouse" /v "MouseThreshold1" /t REG_SZ /d "0" /f >nul 2>&1
if errorlevel 1 goto err_all3
reg add "HKCU\Control Panel\Mouse" /v "MouseThreshold2" /t REG_SZ /d "0" /f >nul 2>&1
if errorlevel 1 goto err_all3
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects" /v "VisualFXSetting" /t REG_DWORD /d 2 /f >nul 2>&1
if errorlevel 1 goto err_all3
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize" /v "EnableTransparency" /t REG_DWORD /d 0 /f >nul 2>&1
if errorlevel 1 goto err_all3
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Serialize" /v "StartupDelayInMSec" /t REG_DWORD /d 0 /f >nul 2>&1
if errorlevel 1 goto err_all3

call :progress "NETWORK"
ipconfig /flushdns >nul 2>&1
if errorlevel 1 goto err_all4

call :progress "CLEANUP"
if defined TEMP (
    del /f /q "%TEMP%\*" >nul 2>&1
    for /d %%D in ("%TEMP%\*") do rd /s /q "%%D" >nul 2>&1
)

call :progress "FINISHING"
powercfg /hibernate off >nul 2>&1
if errorlevel 1 goto err_all5

set "STATUS=All free tweaks applied. Restart Windows for best results."
set "LASTERROR=NONE"
goto done


:: =========================================================
:: SYSTEM INFO
:: =========================================================
:sysinfo
cls
color 0%ACCENT%
echo.
echo                         ==========================================
echo                                  SYSTEM INFO
echo                         ==========================================
echo.

set "CPU=Unknown"
set "GPU=Unknown"
set "RAMGB=Unknown"
set "OSNAME=Unknown"

for /f "usebackq delims=" %%A in (`powershell -NoProfile -Command "$x=(Get-CimInstance Win32_Processor | Select-Object -First 1).Name; if($x){$x}" 2^>nul`) do set "CPU=%%A"
for /f "usebackq delims=" %%A in (`powershell -NoProfile -Command "$x=(Get-CimInstance Win32_VideoController | Select-Object -First 1).Name; if($x){$x}" 2^>nul`) do set "GPU=%%A"
for /f "usebackq delims=" %%A in (`powershell -NoProfile -Command "$x=(Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory; if($x){[math]::Round($x/1GB,1)}" 2^>nul`) do set "RAMGB=%%A"
for /f "usebackq delims=" %%A in (`powershell -NoProfile -Command "$x=(Get-CimInstance Win32_OperatingSystem).Caption; if($x){$x}" 2^>nul`) do set "OSNAME=%%A"

echo                         CPU : !CPU!
echo                         GPU : !GPU!
echo                         RAM : !RAMGB! GB
echo                         OS  : !OSNAME!
echo.
echo                         ------------------------------------------
echo                         Press any key to return.
pause >nul
goto menu


:: =========================================================
:: COLORS
:: =========================================================
:colors
cls
echo.
echo                         ==========================================
echo                                  ACCENT COLOR
echo                         ==========================================
echo.
echo                         [1] Purple
echo                         [2] Light Purple
echo                         [3] Cyan
echo                         [4] Green
echo                         [5] Red
echo                         [6] White
echo.
set "col="
set /p "col=                         Select: "

if "!col!"=="1" set "ACCENT=5"
if "!col!"=="2" set "ACCENT=D"
if "!col!"=="3" set "ACCENT=B"
if "!col!"=="4" set "ACCENT=A"
if "!col!"=="5" set "ACCENT=C"
if "!col!"=="6" set "ACCENT=F"

set "STATUS=Accent color updated."
goto menu


:: =========================================================
:: RECOMMENDATIONS
:: =========================================================
:recommend
cls
color 0%ACCENT%
echo.
echo                         ==========================================
echo                                  RECOMMENDATIONS
echo                         ==========================================
echo.
echo                         Keep Windows and GPU drivers updated.
echo                         Close background apps you do not need.
echo                         Avoid stacking random registry tweak packs.
echo                         Keep 15-20%% of your system drive free.
echo                         Use an SSD for Windows and your main games.
echo.
echo                         ------------------------------------------
echo                         SUPPORT CODES
echo                         ------------------------------------------
echo                         SC-ADM   Administrator access
echo                         SC-PWR   Power settings
echo                         SC-GME   Game Mode
echo                         SC-DVR   Game DVR
echo                         SC-MSE   Mouse settings
echo                         SC-VFX   Visual effects
echo                         SC-UI    Windows UI
echo                         SC-BOOT  Startup settings
echo                         SC-NET   Network
echo                         SC-CLN   Cleanup
echo                         SC-ALL   Apply All
echo.
echo                         Send the full SC code to staff if needed.
echo.
echo                         ------------------------------------------
echo                         Want the full Sin City tweak menu?
echo                         saintsnsinners.org
echo.
pause >nul
goto menu


:: =========================================================
:: SUCCESS SCREEN
:: =========================================================
:done
cls
color 0A
echo.
echo.
echo                         ==========================================
echo                                   COMPLETE
echo                         ==========================================
echo.
echo                         !STATUS!
echo.
echo                         Returning to menu...
>nul ping 127.0.0.1 -n 2 -w 500
goto menu


:: =========================================================
:: STARTUP INTRO
:: =========================================================
:intro
cls
color 0D

for /L %%A in (1,1,5) do (
    cls
    echo.
    echo             !random!          !random!          !random!          !random!
    echo.
    echo                         S I N   C I T Y
    echo.
    echo             !random!          !random!          !random!          !random!
    echo.
    >nul ping 127.0.0.1 -n 1 -w 90
)

cls
echo.
echo.
echo                         ==========================================
echo                                  S I N   C I T Y
echo                               F R E E   T W E A K S
echo                         ==========================================
echo.
call :progress "LOADING"
exit /b


:: =========================================================
:: COLORED LOADING BAR
:: =========================================================
:progress
set "PMSG=%~1"
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
 "$m='%PMSG%';" ^
 "for($i=0;$i -le 100;$i+=10){" ^
 "$f=[math]::Floor($i/5);$e=20-$f;" ^
 "Write-Host -NoNewline ([char]13+'                         '+$m+' [') -ForegroundColor DarkGray;" ^
 "Write-Host -NoNewline ('#'*$f) -ForegroundColor Magenta;" ^
 "Write-Host -NoNewline (('-'*$e)+('] {0,3}%%' -f $i)) -ForegroundColor DarkGray;" ^
 "Start-Sleep -Milliseconds 40};Write-Host"
exit /b


:: =========================================================
:: ERROR SCREENS
:: =========================================================
:showerror
cls
color 0C
echo.
echo                         ==========================================
echo                                    ERROR
echo                         ==========================================
echo.
echo                         Code    : !ERRCODE!
echo                         Details : !ERRMSG!
echo.
echo                         Give the full code above to Sin City staff.
echo.
echo                         saintsnsinners.org
echo.
pause
color 0%ACCENT%
goto menu

:err_pwr1
set "ERRCODE=SC-PWR-001"
set "ERRMSG=High Performance power plan failed."
set "LASTERROR=!ERRCODE!"
goto showerror

:err_pwr2
set "ERRCODE=SC-PWR-002"
set "ERRMSG=Hibernation could not be disabled."
set "LASTERROR=!ERRCODE!"
goto showerror

:err_gme1
set "ERRCODE=SC-GME-001"
set "ERRMSG=Game Mode registry update failed."
set "LASTERROR=!ERRCODE!"
goto showerror

:err_dvr1
set "ERRCODE=SC-DVR-001"
set "ERRMSG=Game DVR registry update failed."
set "LASTERROR=!ERRCODE!"
goto showerror

:err_mse1
set "ERRCODE=SC-MSE-001"
set "ERRMSG=Mouse settings could not be updated."
set "LASTERROR=!ERRCODE!"
goto showerror

:err_vfx1
set "ERRCODE=SC-VFX-001"
set "ERRMSG=Visual effects setting failed."
set "LASTERROR=!ERRCODE!"
goto showerror

:err_ui1
set "ERRCODE=SC-UI-001"
set "ERRMSG=Transparency setting failed."
set "LASTERROR=!ERRCODE!"
goto showerror

:err_boot1
set "ERRCODE=SC-BOOT-001"
set "ERRMSG=Startup delay setting failed."
set "LASTERROR=!ERRCODE!"
goto showerror

:err_net1
set "ERRCODE=SC-NET-001"
set "ERRMSG=DNS cache flush failed."
set "LASTERROR=!ERRCODE!"
goto showerror

:err_cln1
set "ERRCODE=SC-CLN-001"
set "ERRMSG=Windows TEMP folder could not be found."
set "LASTERROR=!ERRCODE!"
goto showerror

:err_all1
set "ERRCODE=SC-ALL-001"
set "ERRMSG=Apply All failed during power setup."
set "LASTERROR=!ERRCODE!"
goto showerror

:err_all2
set "ERRCODE=SC-ALL-002"
set "ERRMSG=Apply All failed during gaming setup."
set "LASTERROR=!ERRCODE!"
goto showerror

:err_all3
set "ERRCODE=SC-ALL-003"
set "ERRMSG=Apply All failed during Windows setup."
set "LASTERROR=!ERRCODE!"
goto showerror

:err_all4
set "ERRCODE=SC-ALL-004"
set "ERRMSG=Apply All failed during network setup."
set "LASTERROR=!ERRCODE!"
goto showerror

:err_all5
set "ERRCODE=SC-ALL-005"
set "ERRMSG=Apply All failed during final power setup."
set "LASTERROR=!ERRCODE!"
goto showerror


:: =========================================================
:: EXIT
:: =========================================================
:end
cls
color 07
echo.
echo.
echo                              Thanks for using Sin City.
echo.
echo                              saintsnsinners.org
echo.
>nul ping 127.0.0.1 -n 2 -w 450
exit /b
